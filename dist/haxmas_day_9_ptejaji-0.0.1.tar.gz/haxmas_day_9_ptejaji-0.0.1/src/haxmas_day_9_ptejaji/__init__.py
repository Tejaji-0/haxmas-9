"""Haxmas Day 9 - Advent Calendar"""

__version__ = "0.0.1"
